# Example of usage u8g2 graphic library with STM32 MCU
